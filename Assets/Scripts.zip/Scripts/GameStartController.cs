using UnityEngine;

public class GameStartController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //5�b��ɍ폜
        GameObject scene_manager = GameObject.Find("GameSceneManager");

        Destroy(gameObject, scene_manager.GetComponent<GameSceneController>().startDirectionTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
