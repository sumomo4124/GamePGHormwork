using UnityEngine;

public class Enemy02Controller : MonoBehaviour
{
	public GameObject effectPrefab = null;
	float timer = 0;

    void Start()
    {
        
    }

    void Update()
    {
        // ���Ԍv��
        timer += Time.deltaTime;
        if (timer >= 2.0f)
        {
            timer = 0.0f;
        }

        // �ړ�
        float speed_x = -1.0f;
        float speed_y = 1.0f;

        if (timer < 1.0f)
        {
            speed_y *= -1.0f;
        }

        float move_x = speed_x * Time.deltaTime;
        float move_y = speed_y * Time.deltaTime;

        transform.Translate(move_x, move_y, 0.0f);

        //��ʊO�̂���ꏊ�܂ōs������Enemy02���폜����
        if (transform.position.x <= -10.0f)
		{
			Destroy(gameObject);
		}
	}

	void OnTriggerEnter2D(Collider2D collision)
	{
        // &&
        // ||
        //��������tag��PlayerBullet��Player�Ȃ�Enemy02���폜
        if (collision.tag == "PlayerBullet" || collision.tag == "Player")
		{
			Instantiate(effectPrefab, transform.position, Quaternion.identity);
			Destroy(gameObject);
		}
	}

}
